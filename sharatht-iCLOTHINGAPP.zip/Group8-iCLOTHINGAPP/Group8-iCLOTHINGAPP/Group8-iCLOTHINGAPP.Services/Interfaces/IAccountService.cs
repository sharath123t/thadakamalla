﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at AccountService.cs
    public interface IAccountService
    {
        Task<RegisterModel> RegisterUser(RegisterModel model);
        Task<LoginModel> LoginUser(LoginModel model);
        CustomerViewModel UpsertCustomer(Customer model);
        CustomerViewModel GetProfile(string userName);
        Task Logout();
    }
}
