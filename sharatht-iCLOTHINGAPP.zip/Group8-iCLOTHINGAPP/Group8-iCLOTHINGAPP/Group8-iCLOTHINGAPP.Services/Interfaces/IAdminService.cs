﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at AdminService.cs
    public interface IAdminService
    {
        Task<bool> UpSertAboutUs(AboutUs obj);
        IEnumerable<AboutUs> GetAllAboutUS();
        AboutUs GetAboutUs(int abtID);
        AdminDBViewModel GetAdminDB();
        IEnumerable<IdentityUser> GetUsers();
    }
}
