﻿using Group8_iCLOTHINGAPP.Data.Models;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at UserService.cs
    public interface IUserService
    {
        Task<bool> InsertComments(Comments cmt);
        Task<bool> InsertQueries(UserQueries mdl);
    }
}
