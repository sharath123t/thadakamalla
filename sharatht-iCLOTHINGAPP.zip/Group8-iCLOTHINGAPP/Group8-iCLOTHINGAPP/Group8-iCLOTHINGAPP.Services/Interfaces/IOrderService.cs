﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at OrderService.cs
    public interface IOrderService
    {
        PurchaseOrderViewModel GetOrders(string userName, string role);
        PurchaseOrders GetOrder(int poId);
        Task<int> UpdateOrderStatus(int poId, int status);
        BillingViewModel GetBillings(string userName, string role);
    }
}
