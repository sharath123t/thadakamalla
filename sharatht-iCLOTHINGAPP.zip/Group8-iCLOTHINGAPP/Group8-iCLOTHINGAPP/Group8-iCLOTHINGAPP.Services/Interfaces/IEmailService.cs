﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at EmailService.cs
    public interface IEmailService
    {
        void SendEmail(MailRequest mailRequest);
    }
}
