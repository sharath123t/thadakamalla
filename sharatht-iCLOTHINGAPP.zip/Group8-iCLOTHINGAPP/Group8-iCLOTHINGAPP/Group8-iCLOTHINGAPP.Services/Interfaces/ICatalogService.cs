﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at CatalogService.cs
    public interface ICatalogService
    {
        #region "Brands"
        IEnumerable<Brand> GetAllBrands();
        Brand GetBrand(int brandId);
        Task<bool> UpSertBrand(Brand brand);
        bool DeleteBrand(int brandId);
        #endregion

        #region "Departments"
        IEnumerable<Department> GetAllDepartments();
        Department GetDepartment(int deptId);
        Task<bool> UpSertDepartment(Department deptId);
        bool DeleteDepartment(int deptId);
        #endregion

        #region "Categories"
        IEnumerable<Category> GetAllCategories();
        Category GetCategory(int CategoryId);
        Task<bool> UpSertCategory(Category Category);
        bool DeleteCategory(int CategoryId);
        #endregion

        #region "Products"
        IEnumerable<Product> GetAllProducts();
        Product GetProduct(int prodId);
        Task<bool> UpSertProduct(Product product);
        bool DeleteProduct(int prodId);
        #endregion

        IEnumerable<ProductViewModel> GetRandomProducts(int prodId = 0);
        SearchResultsModel Search(string searchTerm = null, string category = null, string department = null, string brands = null);
    }
}
