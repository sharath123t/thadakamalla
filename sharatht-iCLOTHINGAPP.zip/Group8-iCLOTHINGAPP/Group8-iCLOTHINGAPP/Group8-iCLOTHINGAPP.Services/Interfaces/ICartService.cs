﻿using Group8_iCLOTHINGAPP.Data.DTOs;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    //This interface has been implementd at CartService.cs
    public interface ICartService
    {
        CartResultModel AddToCart(int prodId, int qty, string userName);
        public CartResultModel GetCart(string userName, bool isAdd = false, int cartId = 0);
        int GetCartItemsCount(string userName);
        public CartResultModel RemoveProductFromCart(string userName, int prodId);
        ResponseModel PlaceOrder(string userName, CardViewModel model);
        CartResultModel BuyNow(int prodId, string userName);
        ResponseModel PlaceOrderForBuyNow(string userName, CardViewModel model);
    }
}
