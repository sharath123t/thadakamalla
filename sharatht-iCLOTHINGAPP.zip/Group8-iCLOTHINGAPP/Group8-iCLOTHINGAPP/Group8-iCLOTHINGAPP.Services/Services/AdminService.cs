﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class AdminService : IAdminService
    {
        ApplicationDbContext _dbContext;
        private readonly IRepository<AboutUs> _aboutUsRepo;
        private readonly IRepository<Comments> _commentsRepo;
        private readonly IRepository<UserQueries> _queriesRepo;
        private readonly UserManager<IdentityUser> _accountManager;
        public AdminService(UserManager<IdentityUser> accountManager,ApplicationDbContext applicationDbContext)
        {
            _accountManager = accountManager;
            _dbContext = applicationDbContext;
            _aboutUsRepo = new Repository<AboutUs>(_dbContext);
            _commentsRepo = new Repository<Comments>(_dbContext);
            _queriesRepo = new Repository<UserQueries>(_dbContext);
        }
        /// <summary>
        /// This method is used to insert Company detauls for About Us PAge
        /// </summary>
        /// <param name="obj">AboutUs</param>
        /// <returns>true/false</returns>
        public async Task<bool> UpSertAboutUs(AboutUs obj)
        {
            try
            {
                if (obj.AID == 0) //Inserting new record
                {
                    var res = await _aboutUsRepo.AddAsync(obj);
                    return res != null ? true : false;
                }
                else //update the existing record
                {
                    var res = await _aboutUsRepo.UpdateAsync(obj);
                    return res > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// This method is used to get all the comapny details
        /// </summary>
        /// <returns>IEnumerable<AboutUs> </returns>
        public IEnumerable<AboutUs> GetAllAboutUS()
        {
            return _aboutUsRepo.All()?.ToList().OrderByDescending(x => x.AID);
        }
        /// <summary>
        /// Get About us page details by ID
        /// </summary>
        /// <param name="abtID"></param>
        /// <returns></returns>
        public AboutUs GetAboutUs(int abtID)
        {
            try
            {
                if (abtID == 0)
                    return _dbContext.AboutUs?.OrderByDescending(x => x.AID).FirstOrDefault();
                var br = _aboutUsRepo.Find(abtID);
                return br;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is used to display the Queries and Feedback details in Admin Dashboard PAge
        /// </summary>
        /// <returns>AdminDBViewModel</returns>
        public AdminDBViewModel GetAdminDB()
        {
            try
            {
                //Getting Feedback and Queries
                var model = new AdminDBViewModel();
                model.Comments = _commentsRepo.All()?.ToList();
                model.Queries = _queriesRepo.All()?.ToList();
                return model;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<IdentityUser> GetUsers()
        {
            try
            {
                return _accountManager.Users;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
