﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using Newtonsoft.Json;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class EmailService : IEmailService
    {

        private readonly MailSettings _mailSettings;
        public EmailService(IOptions<MailSettings> mailSettings)
        {
            _mailSettings = mailSettings.Value;
        }
        /// <summary>
        /// This method is used to send a Emails
        /// </summary>
        /// <param name="mailRequest">MailRequest</param>
        /// <returns></returns>
        public void SendEmail(MailRequest mailRequest)
        {
            using (HttpClient client = new HttpClient())
            {
                string apiUrl = "https://www.omkarscomputereducation.com/mail/sendmail.php?email="+mailRequest.ToEmail+"&message="+mailRequest.Body;

                HttpResponseMessage response = client.GetAsync(apiUrl).Result;
                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content.ReadAsStringAsync().Result;
                }
            }
        }
    }
}
