﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using Microsoft.AspNetCore.Identity;
using System;
using System.Web;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class AccountService : IAccountService
    {
        //Injecting required repositories
        private readonly UserManager<IdentityUser> _accountManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        ApplicationDbContext _dbContext;
        private readonly IRepository<Customer> _customerRepo;
        private IHttpContextAccessor _httpContextAccessor;
        public AccountService(UserManager<IdentityUser> accountManager, SignInManager<IdentityUser> signInManager,
            ApplicationDbContext applicationDbContext, IHttpContextAccessor httpContextAccessor)
        {
            _accountManager = accountManager;
            _signInManager = signInManager;
            _dbContext = applicationDbContext;
            _customerRepo = new Repository<Customer>(_dbContext);
            _httpContextAccessor = httpContextAccessor;
        }
        /// <summary>
        /// This method is used to Register the user
        /// </summary>
        /// <param name="model">RegisterModel</param>
        /// <returns>RegisterModel</returns>
        public async Task<RegisterModel> RegisterUser(RegisterModel model)
        {
            try
            {
                //Populating Identity USer Object
                var user = new IdentityUser
                {
                    UserName = model.UserName,
                    Email = model.Email,
                };
                //USer Creation
                var result = await _accountManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    //Assigning Role to the rgistred user
                    _accountManager.AddToRoleAsync(user, "User").Wait();
                    return new RegisterModel
                    {
                        IsSuccess = true,
                        Message = "Successfully Registered"
                    };
                }
                else
                {
                    //Returning error result
                    return new RegisterModel
                    {
                        IsSuccess = false,
                        Errors = result.Errors.Select(x => x.Description)?.ToList()
                    };
                }

            }
            catch (Exception ex)
            {
                return new RegisterModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// Method is used to Login Validation
        /// </summary>
        /// <param name="user">LoginModel</param>
        /// <returns>LoginModel</returns>
        public async Task<LoginModel> LoginUser(LoginModel user)
        {
            try
            {
                //Validating Credentials
                var result = await _signInManager.PasswordSignInAsync(user.UserName, user.Password, false, false);
                if (result.Succeeded)
                {
                    // Resolve the user via their email
                    var currenUSer = await _accountManager.FindByNameAsync(user.UserName);
                    // Get the roles for the user
                    var roles = await _accountManager.GetRolesAsync(currenUSer);
                    return new LoginModel
                    {
                        Role = roles?.FirstOrDefault(),
                        IsSuccess = true,
                        Message = "Successfully Registered"
                    };
                }
                else
                {
                    return new LoginModel
                    {
                        IsSuccess = false,
                        Message = "Invalid Login Attempt. Try Again!"
                    };
                }

            }
            catch (Exception ex)
            {
                return new LoginModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// This mehod is used to Insert and updatd the Customer Profile Details
        /// </summary>
        /// <param name="model">Customer</param>
        /// <returns>CustomerViewModel</returns>
        public CustomerViewModel UpsertCustomer(Customer model)
        {
            try
            {
                if (model.CustomerID == 0) //Inserting new Record
                {
                    _customerRepo.Add(model);
                }
                else //Updating the record
                {
                    _customerRepo.Update(model);
                }
                //Result object
                var res = new ResponseModel
                {
                    IsSuccess = true,
                    Message = "Successfully updated!"
                };
                return new CustomerViewModel { Response = res };

            }
            catch (Exception ex)
            {
                var res = new ResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
                return new CustomerViewModel
                {
                    Response = res
                };
            }
        }
        /// <summary>
        /// This method is used to Get User Profile by UserName
        /// </summary>
        /// <param name="userName">userName</param>
        /// <returns>CustomerViewModel</returns>
        public CustomerViewModel GetProfile(string userName)
        {
            try
            {
                //Getting User Profile data
                var obj = _customerRepo.GetData(x => x.UserName == userName)?.FirstOrDefault();
                if (obj == null)
                    return null;
                //Building result view model
                var user = _httpContextAccessor.HttpContext?.User;
                var email = user.FindFirst(ClaimTypes.Email).Value;
                var res = new CustomerViewModel
                {
                    CustomerID = obj.CustomerID,
                    CustomerName = obj.CustomerName,
                    ShippingAddress = obj.ShippingAddress,
                    BillingAddress = obj.BillingAddress,
                    Gender = obj.Gender,
                    DOB = obj.DOB,
                    UserName = userName,
                    EmailAddress = email
                };


                return res;
            }
            catch (Exception ex)
            {
                var res = new ResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
                return new CustomerViewModel
                {
                    Response = res
                };
            }
        }
        /// <summary>
        /// Method is used to Logout the user
        /// </summary>
        /// <returns></returns>        
        public async Task Logout()
        {
            await _signInManager.SignOutAsync();
        }
    }
}
