﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Services
{
    public class CatalogService : ICatalogService
    {
        //injucting entity injection
        ApplicationDbContext _dbContext;
        private readonly IRepository<Brand> _brandRepo;
        private readonly IRepository<Department> _deptRepo;
        private readonly IRepository<Category> _categoryRepo;
        private readonly IRepository<Product> _productRepo;
        //consstrucctor intitalization
        public CatalogService(ApplicationDbContext applicationDbContext)
        {
            _dbContext = applicationDbContext;
            _brandRepo = new Repository<Brand>(_dbContext);
            _deptRepo = new Repository<Department>(_dbContext);
            _categoryRepo = new Repository<Category>(_dbContext);
            _productRepo = new Repository<Product>(_dbContext);
        }
        #region "Brand"
        /// <summary>
        /// Method to insert and update the  brand details
        /// </summary>
        /// <param name="brand">Brand</param>
        /// <returns>true</returns>
        public async Task<bool> UpSertBrand(Brand brand)
        {
            try
            {
                if (brand.BrandID == 0) //If New Entry
                {
                    var res = await _brandRepo.AddAsync(brand);
                    return res != null ? true : false;
                }
                else //Updating existing Record
                {
                    var res = await _brandRepo.UpdateAsync(brand);
                    return res > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Method to delete the brand
        /// </summary>
        /// <param name="brandId">1</param>
        /// <returns>true</returns>
        public bool DeleteBrand(int brandId)
        {
            try
            {
                var brand = _brandRepo.Find(brandId);
                _brandRepo.Delete(brand);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Method to get list of all the brands
        /// </summary>
        /// <returns>List<Brand></Brand></returns>
        public IEnumerable<Brand> GetAllBrands()
        {
            return _brandRepo.All()?.ToList().OrderByDescending(x => x.BrandID);
        }
        /// <summary>
        /// Method to get brand details by brand ID
        /// </summary>
        /// <param name="brandId">1</param>
        /// <returns>Brand</Brand></returns>
        public Brand GetBrand(int brandId)
        {
            try
            {
                var br = _brandRepo.Find(brandId);
                return br;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "Departments"
        /// <summary>
        /// Method to Insert and Update the Department
        /// </summary>
        /// <param name="dept"></param>
        /// <returns>true</returns>
        public async Task<bool> UpSertDepartment(Department dept)
        {
            try
            {
                if (dept.DepartmentID == 0) //If new record
                {
                    var res = await _deptRepo.AddAsync(dept);
                    return res != null ? true : false;
                }
                else //updating existing record
                {
                    var res = await _deptRepo.UpdateAsync(dept);
                    return res > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Method to Delete Department by Department Id
        /// </summary>
        /// <param name="deptId">2</param>
        /// <returns>true</returns>
        public bool DeleteDepartment(int deptId)
        {
            try
            {
                var department = _deptRepo.Find(deptId);
                _deptRepo.Delete(department);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Method to get all Departments list
        /// </summary>
        /// <returns>List<Department></returns>
        public IEnumerable<Department> GetAllDepartments()
        {
            return _deptRepo.All()?.ToList().OrderByDescending(x => x.DepartmentID);
        }
        /// <summary>
        /// This method is used to get department by department ID
        /// </summary>
        /// <param name="deptId">4</param>
        /// <returns>Department</returns>
        public Department GetDepartment(int deptId)
        {
            try
            {
                var br = _deptRepo.Find(deptId);
                return br;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "Category"
        /// <summary>
        /// This methd is used to Insert and update the Category 
        /// </summary>
        /// <param name="category"></param>
        /// <returns>true</returns>
        public async Task<bool> UpSertCategory(Category category)
        {
            try
            {
                if (category.CategoryID == 0)
                {
                    var res = await _categoryRepo.AddAsync(category); //Inserting new category
                    return res != null ? true : false;
                }
                else //updating category
                {
                    var res = await _categoryRepo.UpdateAsync(category);
                    return res > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Methosd is used to delete the category by id
        /// </summary>
        /// <param name="categoryId">3</param>
        /// <returns>true</returns>
        public bool DeleteCategory(int categoryId)
        {
            try
            {
                var category = _categoryRepo.Find(categoryId);
                _categoryRepo.Delete(category);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Used to get all the categories
        /// </summary>
        /// <returns>List<Category></Category></returns>
        public IEnumerable<Category> GetAllCategories()
        {
            return _categoryRepo.All()?.ToList().OrderByDescending(x => x.CategoryID);
        }
        /// <summary>
        /// Method is used to get category by id
        /// </summary>
        /// <param name="categoryId">3</param>
        /// <returns>Category</returns>
        public Category GetCategory(int categoryId)
        {
            try
            {
                var br = _categoryRepo.Find(categoryId);
                return br;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "Product"
        /// <summary>
        /// This method is used to insert and updated the product details
        /// </summary>
        /// <param name="product"></param>
        /// <returns>true</returns>
        public async Task<bool> UpSertProduct(Product product)
        {
            try
            {
                if (product.ProductID == 0) //inserting new product
                {
                    var res = await _productRepo.AddAsync(product);
                    return res != null ? true : false;
                }
                else //updating the existing product
                {
                    product.ModifiedBy = "Admin";
                    product.ModifiedOn = DateTime.Now;
                    var res = await _productRepo.UpdateAsync(product);
                    return res > 0 ? true : false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// This method is used to delete the product
        /// </summary>
        /// <param name="productId">2</param>
        /// <returns>true</returns>
        public bool DeleteProduct(int productId)
        {
            try
            {
                var product = _productRepo.Find(productId);
                _productRepo.Delete(product);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// To get all the products
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Product> GetAllProducts()
        {
            return _productRepo.All()?.ToList().OrderByDescending(x => x.ProductID);
        }
        /// <summary>
        /// Get the product by product id
        /// </summary>
        /// <param name="productId">2</param>
        /// <returns>Product</returns>
        public Product GetProduct(int productId)
        {
            try
            {
                var br = _productRepo.Find(productId);
                return br;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "Common"
        /// <summary>
        /// This method is used to get the products for display in UI
        /// This will returns Random products if prodID == 0 for Home Page
        /// id prodId !=0, it will returns the particular product details with brand, category and department
        /// </summary>
        /// <param name="prodID"></param>
        /// <returns></returns>
        public IEnumerable<ProductViewModel> GetRandomProducts(int prodID = 0)
        {
            var result = GetProducts();
            if (prodID != 0)
                return result.Where(x => x.ProductID == prodID);
            else
                return result.OrderBy(r => Guid.NewGuid()).Take(8);
        }
        /// <summary>
        /// This method is used to get the search results by givben filters
        /// </summary>
        /// <param name="searchTerm">women</param>
        /// <param name="category">1,2,3</param>
        /// <param name="department">2,4</param>
        /// <param name="brands">4,5</param>
        /// <returns></returns>
        public SearchResultsModel Search(string searchTerm = null, string category = null, string department = null, string brands = null)
        {
            var allProds = GetProducts();
            if (!string.IsNullOrEmpty(searchTerm)) //Filtering in search term is exists
            {
                allProds = allProds.Where(x => x.ProductName.Contains(searchTerm) ||
                x.ProductDescription.ToLower().Contains(searchTerm));
            }
            //Filtering by selected departments
            if (!string.IsNullOrEmpty(department))
            {
                IEnumerable<int> deptIds = department.Split(',').Select(str => int.Parse(str));
                allProds = allProds.Where(rec => deptIds.Contains(rec.DepartmentID));
            }
            //Filtering by categories
            if (!string.IsNullOrEmpty(category))
            {
                IEnumerable<int> catIds = category.Split(',').Select(str => int.Parse(str));
                allProds = allProds.Where(rec => catIds.Contains(rec.CategoryID));
            }
            //Filetring by brands
            if (!string.IsNullOrEmpty(brands))
            {
                IEnumerable<int> brandIds = brands.Split(',').Select(str => int.Parse(str));
                allProds = allProds.Where(rec => brandIds.Contains(rec.BrandID));
            }
            //Building Result Model for Search Result
            var result = new SearchResultsModel
            {
                Categories = GetAllCategories(),
                Brands = GetAllBrands(),
                Departments = GetAllDepartments(),
                Products = allProds,
                Total = allProds.Count()
            };
            return result;
        }

        #endregion
        /// <summary>
        /// This methid is used to build the PRoduct View Model
        /// </summary>
        /// <returns></returns>
        private IEnumerable<ProductViewModel> GetProducts()
        {
            var result = (from p in _dbContext.Products
                          join c in _dbContext.Categories on p.CategoryID equals c.CategoryID
                          join b in _dbContext.Brands on p.BrandID equals b.BrandID
                          join d in _dbContext.Departments on p.DepartmentID equals d.DepartmentID
                          select new ProductViewModel
                          {
                              ProductID = p.ProductID,
                              ProductName = p.ProductName,
                              ProductDescription = p.ProductDescription,
                              ProductPrice = p.ProductPrice,
                              ProductQuantity = p.ProductQuantity,
                              ImagePath = p.ImagePath,
                              BrandName = b.BrandName,
                              IsLastItem = p.ProductQuantity == 1 ? true : false,
                              CategoryName = c.CategoryName,
                              DepartmentName = d.DepartmentName,
                              CategoryID = c.CategoryID,
                              BrandID = b.BrandID,
                              DepartmentID = d.DepartmentID
                          });
            return result;
        }
    }
}
