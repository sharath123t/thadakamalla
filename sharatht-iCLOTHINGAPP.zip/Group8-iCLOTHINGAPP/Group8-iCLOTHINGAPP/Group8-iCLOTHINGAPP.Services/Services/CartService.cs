﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class CartService : ICartService
    {

        ApplicationDbContext _dbContext;
        private readonly IRepository<ShoppingCart> _cartRepo;
        private readonly IRepository<OrderStatus> _statusRepo;
        private readonly IRepository<PurchaseOrder> _pOrderRepo;
        private readonly IRepository<CreditCard> _cardRepo;
        private readonly IRepository<Product> _productRepo;
        private readonly ICatalogService _catelogService;
        private readonly IAccountService _accountService;
        private readonly IEmailService _emailService;
        public CartService(ApplicationDbContext applicationDbContext, ICatalogService catelogService,
            IAccountService accountService, IEmailService emailService)
        {
            _dbContext = applicationDbContext;
            _cartRepo = new Repository<ShoppingCart>(_dbContext);
            _statusRepo = new Repository<OrderStatus>(_dbContext);
            _pOrderRepo = new Repository<PurchaseOrder>(_dbContext);
            _productRepo = new Repository<Product>(_dbContext);
            _cardRepo = new Repository<CreditCard>(_dbContext);
            this._catelogService = catelogService;
            this._accountService = accountService;
            this._emailService = emailService;
        }
        /// <summary>
        /// This method is used to Add product to CART
        /// </summary>
        /// <param name="prodId">1</param>
        /// <param name="qty">2</param>
        /// <param name="userName">Group8</param>
        /// <returns>CartResultModel</returns>
        public CartResultModel AddToCart(int prodId, int qty, string userName)
        {
            try
            {
                var cart = LoadOrCreateCart(userName); //Will Get existing cart or new cart for the user 
                if (cart == null)
                {
                    //If profile not updated returning with message
                    return new CartResultModel
                    {
                        IsSuccess = false,
                        Message = "Please Update Profile Details"
                    };
                }
                //Getting Product Details
                var prod = _catelogService.GetRandomProducts(prodId)?.FirstOrDefault();
                //Building Line Item Model
                var linItem = new LineItems
                {
                    ProductDescription = prod.ProductDescription,
                    ImagePath = prod.ImagePath,
                    BrandName = prod.BrandName,
                    Department = prod.DepartmentName,
                    CategoryName = prod.CategoryName,
                    OrderQuantity = qty,
                    ProductID = prodId,
                    Price = prod.ProductPrice,
                    ProductName = prod.ProductName
                };
                //Deserialzing the line items object
                var lineItems = JsonConvert.DeserializeObject<List<LineItems>>(cart.LineItems);
                if (lineItems.Exists(x => x.ProductID == linItem.ProductID))//If Already product added to the Cart
                {
                    var existingLineItem = lineItems.Where(x => x.ProductID == linItem.ProductID)?.FirstOrDefault();
                    //Getting Existing product quantity and Adding the old quantity alonf with newly added product
                    linItem.OrderQuantity += existingLineItem.OrderQuantity;
                    //removed old product from the cart
                    lineItems.Remove(existingLineItem);
                }
                lineItems.Add(linItem); //Adding  PRoduct to Line Items
                cart.LineItems = JsonConvert.SerializeObject(lineItems);
                cart.ModifiedBy = userName;
                cart.ModifiedOn = DateTime.Now;
                _cartRepo.Update(cart); //Updating the Cart
                //Getting Updated Cart
                var result = GetCart(userName, true);
                return result;
            }
            catch (Exception ex)
            {
                return new CartResultModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// MEthod to get the Load or Create New Cart by User NAme
        /// </summary>
        /// <param name="UserName">Group8</param>
        /// <returns>ShoppingCart</returns>
        public ShoppingCart LoadOrCreateCart(string userName)
        {
            var user = _accountService.GetProfile(userName); //validating whether user updated his profile or not
            if (user == null)
            {
                return null;
            }
            //Getting Cart Deatails
            var cart = _cartRepo.GetData(x => x.UserName == userName && x.IsActive)?.FirstOrDefault();
            if (cart != null)
                return cart;
            //Building Shopping Cart Model
            var cartModel = new ShoppingCart
            {
                UserName = userName,
                ShippingAddress = user.ShippingAddress,
                BillingAddress = user.BillingAddress,
                IsActive = true,
                LineItems = "[]",
                CreatedOn = DateTime.Now,
                CreatedBy = userName
            };
            var newCart = _cartRepo.Add(cartModel); //Adding Cart
            return newCart;
        }
        /// <summary>
        /// Method to get the Cart by User Name
        /// </summary>
        /// <param name="userName">Grou8</param>
        /// <returns>ShoppingCart</returns>
        public CartResultModel GetCart(string userName, bool isAdd = false, int cartId = 0)
        {
            var cart = new ShoppingCart();
            if (cartId == 0) //If cart id = 0  will try to get the cart by user name
                cart = _cartRepo.GetData(x => x.UserName == userName && x.IsActive)?.FirstOrDefault();
            else
                cart = _cartRepo.Find(cartId); //getting cart by cart Id
            if (cart == null)
                return null;
            var lineItems = JsonConvert.DeserializeObject<List<LineItems>>(cart.LineItems);
            var res = new CartResultModel //Populating Cart Result Model
            {
                CartID = cart.CartID,
                TotalItems = lineItems?.Count() ?? 0,
                IsSuccess = true,
                Message = isAdd ? "Item Added to Cart" : string.Empty,
                CartTotal = lineItems.Sum(x => x.Price),
                Products = lineItems
            };
            return res;
        }
        /// <summary>
        /// this method is used to remove the product from cart 
        /// </summary>
        /// <param name="userName">Group8</param>
        /// <param name="prodId">1</param>
        /// <returns>CartResultModel</returns>
        public CartResultModel RemoveProductFromCart(string userName, int prodId)
        {
            try
            {
                //Getting User Cart
                var cart = _cartRepo.GetData(x => x.UserName == userName && x.IsActive)?.FirstOrDefault();
                if (cart == null)
                    return null;
                var lineItems = JsonConvert.DeserializeObject<List<LineItems>>(cart.LineItems);
                var itemTobeRemove = lineItems.Find(x => x.ProductID == prodId); //Finding Line item to be removed
                lineItems.Remove(itemTobeRemove); //removing product
                cart.LineItems = JsonConvert.SerializeObject(lineItems);
                cart.ModifiedBy = userName;
                cart.ModifiedOn = DateTime.Now;
                _cartRepo.Update(cart); //updating the cart
                //Getting Updated Cart
                var result = GetCart(userName);
                return result;
            }
            catch (Exception ex)
            {
                return new CartResultModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// MEthod used to get the cart items count
        /// </summary>
        /// <param name="userName">Group8</param>
        /// <returns>4</returns>
        public int GetCartItemsCount(string userName)
        {
            //GEtting User Cart by user name
            var cart = _cartRepo.GetData(x => x.UserName == userName && x.IsActive)?.FirstOrDefault();
            if (cart == null)
                return 0;
            //Deserializing PRoducts Object
            var products = JsonConvert.DeserializeObject<List<LineItems>>(cart.LineItems);
            return products?.Count() ?? 0;
        }
        /// <summary>
        /// Method is used to Place an Order from Cart PAge
        /// </summary>
        /// <param name="userName">group8</param>
        /// <param name="model">CardViewModel</param>
        /// <returns>ResponseModel</returns>
        public ResponseModel PlaceOrder(string userName, CardViewModel model)
        {
            try
            {
                //Validating Card details with credentials
                var cardDetails = _cardRepo.GetData(x => x.CardNumber == model.CardNumber && x.ExpiryDate == model.ExpiryDate && x.CVV == model.CVV)?.FirstOrDefault();
                if (cardDetails == null) // if wrong creds found returning error
                {
                    return new ResponseModel
                    {
                        IsSuccess = false,
                        Message = "Invalid Credentials"
                    };
                }
                //Getting Active CArt by User name
                var cart = GetCart(userName);
                //Creating Purchase Order Object
                var purchaseOrder = new PurchaseOrder
                {
                    CartID = cart.CartID,
                    StatusID = 1,
                    CreatedBy = userName,
                    CreatedOn = DateTime.Now,
                    CardID = cardDetails.CardID,
                    Amount = model.Amount,
                    IsBuyIn = false
                };
                _pOrderRepo.Add(purchaseOrder); //Inserting PO
                //Sendiing Confirmation Email to Customer
                SendOrderMail(userName, purchaseOrder.PurchaseOrderID, cart);
                //After Placing an Order, desolving existing cart
                DesolveCart(userName);
                return new ResponseModel
                {
                    IsSuccess = true,
                    Message = "Order Placed Succesfully."
                };
            }
            catch (Exception ex)
            {
                return new ResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// This method is used to Place an order of Buy In Products
        /// </summary>
        /// <param name="userName">Group8</param>
        /// <param name="model">CardViewModel</param>
        /// <returns>ResponseModel</returns>
        public ResponseModel PlaceOrderForBuyNow(string userName, CardViewModel model)
        {
            try
            {
                var user = _accountService.GetProfile(userName); //validating whether user updated his profile or not
                if (user == null)
                {
                    return new ResponseModel
                    {
                        IsSuccess = false,
                        Message = "Please Update the Profile and Address Details."
                    };
                }
                //validating give card/payment details
                var cardDetails = _cardRepo.GetData(x => x.CardNumber == model.CardNumber && x.ExpiryDate == model.ExpiryDate && x.CVV == model.CVV)?.FirstOrDefault();
                if (cardDetails == null) //if wrond details returning error message
                {
                    return new ResponseModel
                    {
                        IsSuccess = false,
                        Message = "Invalid Credentials"
                    };
                }
                var prod = _catelogService.GetRandomProducts(model.ProdId)?.FirstOrDefault(); //Gathering product info
                //Creating Line Item for the given product
                var linItem = new LineItems
                {
                    ProductDescription = prod.ProductDescription,
                    ImagePath = prod.ImagePath,
                    BrandName = prod.BrandName,
                    Department = prod.DepartmentName,
                    CategoryName = prod.CategoryName,
                    OrderQuantity = 1,
                    ProductID = model.ProdId,
                    Price = prod.ProductPrice,
                    ProductName = prod.ProductName
                };
                var lineItems = new List<LineItems>();
                lineItems.Add(linItem);
                //Creating cart model object 
                var cartModel = new ShoppingCart
                {
                    UserName = userName,
                    ShippingAddress = user.ShippingAddress,
                    BillingAddress = user.BillingAddress,
                    IsActive = false,
                    LineItems = JsonConvert.SerializeObject(lineItems),
                    CreatedOn = DateTime.Now,
                    CreatedBy = userName
                };
                var newCart = _cartRepo.Add(cartModel); //saving cart
                //creating purchase order
                var purchaseOrder = new PurchaseOrder
                {
                    CartID = newCart.CartID,
                    StatusID = 1,
                    CreatedBy = userName,
                    CreatedOn = DateTime.Now,
                    CardID = cardDetails.CardID,
                    Amount = model.Amount,
                    IsBuyIn = true
                };
                _pOrderRepo.Add(purchaseOrder);
                //Sendiing Confirmation Email to Customer
                var result = GetCart(userName, true, newCart.CartID);
                SendOrderMail(userName, purchaseOrder.PurchaseOrderID, result);
                return new ResponseModel
                {
                    IsSuccess = true,
                    Message = "Order Placed Succesfully."
                };
            }
            catch (Exception ex)
            {
                return new ResponseModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// MEthod used to get buy in product details to show in Cart Page
        /// </summary>
        /// <param name="prodId">5</param>
        /// <param name="userName">group8</param>
        /// <returns></returns>
        public CartResultModel BuyNow(int prodId, string userName)
        {
            try
            {
                //Getting Product Details
                var prod = _catelogService.GetRandomProducts(prodId)?.FirstOrDefault();
                //Building line item object
                var linItem = new LineItems
                {
                    ProductDescription = prod.ProductDescription,
                    ImagePath = prod.ImagePath,
                    BrandName = prod.BrandName,
                    Department = prod.DepartmentName,
                    CategoryName = prod.CategoryName,
                    OrderQuantity = 1,
                    ProductID = prodId,
                    Price = prod.ProductPrice,
                    ProductName = prod.ProductName,
                    IsLast = prod.ProductQuantity == 1 ? true : false
                };
                var lineItems = new List<LineItems>();
                lineItems.Add(linItem);
                //Creating Cart Result model without saving cart
                var res = new CartResultModel
                {
                    TotalItems = lineItems?.Count() ?? 0,
                    CartTotal = lineItems.Sum(x => x.Price),
                    Products = lineItems,
                    IsBuyNow = true
                };
                return res;
            }
            catch (Exception ex)
            {
                return new CartResultModel
                {
                    IsSuccess = false,
                    Message = ex.Message.ToString()
                };
            }
        }
        /// <summary>
        /// MEthod is used to DeActivate the Cart once order placed successfully
        /// </summary>
        /// <param name="user">group8</param>
        private void DesolveCart(string user)
        {
            var cart = _cartRepo.GetData(x => x.UserName == user && x.IsActive)?.FirstOrDefault();
            cart.IsActive = false;
            cart.ModifiedBy = user;
            cart.ModifiedOn = DateTime.Now;
            _cartRepo.Update(cart);
        }

        private void SendOrderMail(string userName, int poId, CartResultModel cart)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<h3>Dear Customer!</h3>");
            sb.Append("<h4>Your Order Placed Successfully</h4>");
            sb.Append("<div><p>Below are the details of your cart.</p></div>");
            sb.Append("<br>");
            sb.Append("<br>");
            //Table start.
            sb.Append("<table cellpadding='5' cellspacing='0' style='border: 1px solid gray;font-size: 9pt;font-family:Arial;width:100%;text-align:left'>");

            //Adding Header Row.
            sb.Append("<tr style='border: 1px solid gray;'>");
            sb.Append("<th>Product Name</th><th>Quantity</th><th>Product Price</th>");
            sb.Append("</tr>");


            //Adding Table Row.
            foreach (var prod in cart.Products)
            {
                sb.Append("<tr style='border: 1px solid gray;'>");
                sb.Append("<td>" + prod.ProductName + "</td>");
                sb.Append("<td>" + prod.OrderQuantity + "</td>");
                sb.Append("<td>" + prod.Price + "</td>");
                sb.Append("</tr>");
            }
            sb.Append("<tr>");
            sb.Append("<td> </td>");
            sb.Append("<td> </td>");
            sb.Append("<td> Total Amount : " + cart.CartTotal + "</td>");
            sb.Append("</tr>");
            //Table end.
            sb.Append("</table>");
            sb.Append("<br>");
            sb.Append("<br>");
            sb.Append("Thanks for Shopping with iClothing!!");
            var cust = _accountService.GetProfile(userName);
            var mailReq = new MailRequest
            {
                ToEmail = cust.EmailAddress,
                Body = sb.ToString(),
                Subject = "iClothing: Order Confirmation"
            };
            _emailService.SendEmail(mailReq);
        }
    }
}
