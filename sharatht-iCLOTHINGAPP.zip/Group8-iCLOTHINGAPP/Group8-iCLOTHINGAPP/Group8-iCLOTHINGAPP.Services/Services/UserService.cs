﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using System;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class UserService : IUserService
    {

        ApplicationDbContext _dbContext;
        private readonly IRepository<Comments> _commentRepo;
        private readonly IRepository<UserQueries> _queriesRepo;
        public UserService(ApplicationDbContext applicationDbContext)
        {
            _dbContext = applicationDbContext;
            _commentRepo = new Repository<Comments>(_dbContext);
            _queriesRepo = new Repository<UserQueries>(_dbContext);
        }

        /// <summary>
        /// Using this method to insert the user comments/feedback
        /// </summary>
        /// <param name="cmt">Comments</param>
        /// <returns>true/false</returns>
        public async Task<bool> InsertComments(Comments cmt)
        {
            try
            {
                cmt.CreatedOn = DateTime.Now;
                var res = await _commentRepo.AddAsync(cmt);
                return res != null ? true : false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// This method is used to Insert User Queries
        /// </summary>
        /// <param name="qry">UserQueries</param>
        /// <returns>true/false</returns>
        public async Task<bool> InsertQueries(UserQueries qry)
        {
            try
            {
                qry.CreatedOn = DateTime.Now;
                var res = await _queriesRepo.AddAsync(qry);
                return res != null ? true : false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
