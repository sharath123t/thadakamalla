﻿using Group8_iCLOTHINGAPP.Data;
using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Data.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Services.Interfaces
{
    public class OrderService : IOrderService
    {
        ApplicationDbContext _dbContext;
        private readonly IRepository<PurchaseOrder> _ordersRepo;
        private readonly ICartService _cartService;
        private readonly IEmailService mailService;
        public OrderService(ApplicationDbContext applicationDbContext, ICartService cartService,
            IEmailService mailService)
        {
            _dbContext = applicationDbContext;
            _ordersRepo = new Repository<PurchaseOrder>(_dbContext);
            this._cartService = cartService;
            this.mailService = mailService;
        }
        /// <summary>
        /// This method is used to Get All Orders of signed in user
        /// For Admin, it will  return all orders list
        /// </summary>
        /// <param name="userName">group8</param>
        /// <param name="role">User</param>
        /// <returns>PurchaseOrderViewModel</returns>
        public PurchaseOrderViewModel GetOrders(string userName, string role)
        {
            try
            {
                var result = (from p in _dbContext.PurchaseOrders
                              join o in _dbContext.OrderStatus on p.StatusID equals o.StatusID
                              join c in _dbContext.ShoppingCarts on p.CartID equals c.CartID
                              join crd in _dbContext.CreditCards on p.CardID equals crd.CardID
                              join cust in _dbContext.Customers on c.UserName equals cust.UserName

                              select new PurchaseOrders
                              {
                                  PoID = p.PurchaseOrderID,
                                  Status = o.Status,
                                  Amount = p.Amount,
                                  CardDetails = crd,
                                  UserName = cust.UserName,
                                  Customer = cust,
                                  OrderDate = p.CreatedOn,
                                  IsBuyIn = p.IsBuyIn

                              })?.ToList();

                if (role != "Admin") // If role is 'User'
                    result = result.Where(x => x.UserName == userName)?.ToList();
                var orders = new PurchaseOrderViewModel // if Role is Admin
                {
                    IsAdmin = role == "Admin" ? true : false,
                    Orders = result
                };
                return orders;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is used to get order details by purchae order id
        /// </summary>
        /// <param name="poId">2</param>
        /// <returns>PurchaseOrders</returns>
        public PurchaseOrders GetOrder(int poId)
        {
            try
            {
                var result = (from p in _dbContext.PurchaseOrders
                              join o in _dbContext.OrderStatus on p.StatusID equals o.StatusID
                              join c in _dbContext.ShoppingCarts on p.CartID equals c.CartID
                              join crd in _dbContext.CreditCards on p.CardID equals crd.CardID
                              join cust in _dbContext.Customers on c.UserName equals cust.UserName
                              where p.PurchaseOrderID == poId
                              select new PurchaseOrders
                              {
                                  PoID = p.PurchaseOrderID,
                                  Status = o.Status,
                                  Amount = p.Amount,
                                  CardDetails = crd,
                                  UserName = cust.UserName,
                                  Customer = cust,
                                  OrderDate = p.CreatedOn,
                                  CartID = p.CartID,
                                  IsBuyIn = p.IsBuyIn
                              })?.FirstOrDefault();
                result.Cart = _cartService.GetCart("", false, result.CartID);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BillingViewModel GetBillings(string userName, string role)
        {
            try
            {
                var result = (from p in _dbContext.PurchaseOrders
                              join o in _dbContext.OrderStatus on p.StatusID equals o.StatusID
                              join c in _dbContext.ShoppingCarts on p.CartID equals c.CartID
                              join crd in _dbContext.CreditCards on p.CardID equals crd.CardID
                              join cust in _dbContext.Customers on c.UserName equals cust.UserName

                              select new BillingDetails
                              {
                                  POID = p.PurchaseOrderID,
                                  CardNumber = crd.CardNumber,
                                  Amount = p.Amount,
                                  CustomerName = cust.CustomerName,
                                  OrderDate = p.CreatedOn,
                                  UserName = cust.UserName
                              })?.ToList();

                if (role != "Admin") // If role is 'User'
                    result = result.Where(x => x.UserName == userName)?.ToList();
                var orders = new BillingViewModel // if Role is Admin
                {
                    IsAdmin = role == "Admin" ? true : false,
                    Billings = result
                };
                return orders;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This methid is used to Update the Order status by Admin
        /// </summary>
        /// <param name="poId">3</param>
        /// <param name="status">1</param>
        /// <returns></returns>
        public async Task<int> UpdateOrderStatus(int poId, int status)
        {
            try
            {
                var po = _ordersRepo.Find(poId);
                po.StatusID = status;
                var res = _ordersRepo.Update(po);
                //var mailReq = new MailRequest
                //{
                //    ToEmail = "prptgt@gmail.com",
                //    Subject = "Order Status Updated",
                //    Body = "<h2>Order Updated</h2>"
                //};
                //await mailService.SendEmailAsync(mailReq);
                return res;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
