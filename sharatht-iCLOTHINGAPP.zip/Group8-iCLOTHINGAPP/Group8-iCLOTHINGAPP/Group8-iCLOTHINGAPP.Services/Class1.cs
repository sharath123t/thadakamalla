﻿using System;

namespace Group8_iCLOTHINGAPP.Services
{
    public class Class1
    {
    }
}
