﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Data.Repos
{
    //Generic Repository to Handle the databse queries which deals and DDL and DML Operations
    public class Repository<T> : IRepository<T> where T : BaseEntity
    {
        protected internal readonly DbContext _dbContext;
        protected internal readonly DbSet<T> _dbSet;
        public Repository(DbContext dbContext)
        {
            if (dbContext == null) throw new ArgumentNullException(nameof(dbContext), $"The parameter dbContext can not be null");

            _dbContext = dbContext;
            _dbSet = _dbContext.Set<T>();
        }

        public IQueryable<T> All()
        {
            _dbSet.Load();

            var result = _dbSet.Local;

            return result.AsQueryable();
        }
        public T Add(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _dbSet.Add(entity);
            _dbContext.SaveChanges();
            return entity;
        }

        public T Find(object pks)
        {
            if (pks == null) throw new ArgumentNullException(nameof(pks), $"The parameter pks can not be null");

            var result = _dbSet.Find(pks);

            return result;
        }
        public IQueryable<T> GetData(Expression<Func<T, bool>> filter)
        {
            if (filter == null) throw new ArgumentNullException(nameof(filter), $"The parameter filter can not be null");

            _dbSet.Where(filter).Load();

            var filterFunc = filter.Compile();

            var result = _dbSet.Local.Where(filterFunc).AsQueryable();

            return result;
        }

        public int Update(T updateEntity)
        {
            var result = 0;
            var dbSet = _dbContext.Set<T>();

            dbSet.Attach(updateEntity);

            _dbContext.Entry(updateEntity).State = EntityState.Modified;

            result = _dbContext.SaveChanges();
            return result;
        }
        public void Delete(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            var dbSet = _dbContext.Set<T>();
            dbSet.Remove(entity);
            _dbContext.SaveChanges();
        }
        public void Dispose()
        {
            if (_dbContext != null) _dbContext.Dispose();
        }

        public async Task<T> AddAsync(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _dbSet.Add(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<int> UpdateAsync(T updateEntity)
        {
            var result = 0;
            var dbSet = _dbContext.Set<T>();

            dbSet.Attach(updateEntity);

            _dbContext.Entry(updateEntity).State = EntityState.Modified;

            result = await _dbContext.SaveChangesAsync();
            return result;
        }

    }
}
