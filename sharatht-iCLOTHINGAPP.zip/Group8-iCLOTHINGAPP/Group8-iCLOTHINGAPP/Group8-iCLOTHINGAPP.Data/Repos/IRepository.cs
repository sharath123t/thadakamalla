﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Data.Repos
{
    public interface IRepository<T> where T : BaseEntity
    {
        IQueryable<T> All();
        void Delete(T entity);
        T Find(object id);
        T Add(T entity);
        int Update(T entity);
        IQueryable<T> GetData(Expression<Func<T, bool>> filter);
        Task<int> UpdateAsync(T updateEntity);
        Task<T> AddAsync(T entity);
    }
}
