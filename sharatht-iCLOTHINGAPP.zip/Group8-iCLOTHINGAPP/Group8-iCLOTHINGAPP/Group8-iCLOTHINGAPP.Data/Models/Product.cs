﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblProducts", Schema = "dbo")]
    public class Product : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductID { get; set; }
        [Required(ErrorMessage = "Enter Product Name")]
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        [Required(ErrorMessage = "Enter Product Price")]
        [Column(TypeName = "decimal(18,2)")]
        [DefaultValue(0.0)]
        public decimal ProductPrice  { get; set; }
        [Required(ErrorMessage = "Enter Product Quantity")]
        public int ProductQuantity{ get; set; }
        public bool IsActive { get; set; }
        public int BrandID { get; set; }
        public int DepartmentID { get; set; }
        public int CategoryID { get; set; }
        public string ImagePath { get; set; }
    }
}
