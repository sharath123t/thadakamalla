﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblCards", Schema = "dbo")]
    public class CreditCard : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CardID { get; set; }
        [Required(ErrorMessage = "Enter Card Holder Name")]
        public string CardHolderName{ get; set; }
        [MaxLength(16)]
        [MinLength(16)]
        [Required(ErrorMessage = "Enter Card Number")]
        public string CardNumber { get; set; }
        [MaxLength(7)]
        [MinLength(7)]
        [Required(ErrorMessage = "Enter Expiry Date")]
        public string ExpiryDate { get; set; }
        [MaxLength(3)]
        [MinLength(3)]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Enter CVV")]
        public string CVV { get; set; }
    }
}
