﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblAboutUs", Schema = "dbo")]
    public class AboutUs : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AID { get; set; }
        [Required(ErrorMessage = "Enter Company Name")]
        public string CompanyName { get; set; }
        [Required(ErrorMessage = "Enter Company Address")]
        public string CompanyAddress { get; set; }
        [Required(ErrorMessage = "Enter Shipping Policy")]
        public string ShipingPolicy { get; set; }
        [Required(ErrorMessage = "Enter Return Ploicy")]
        public string ReturnPolicy { get; set; }
        [Required(ErrorMessage = "Enter Contact Information")]
        public string ContactInfo { get; set; }

        [Required(ErrorMessage = "Enter Business Description")]
        public string Desciption { get; set; }

    }
}
