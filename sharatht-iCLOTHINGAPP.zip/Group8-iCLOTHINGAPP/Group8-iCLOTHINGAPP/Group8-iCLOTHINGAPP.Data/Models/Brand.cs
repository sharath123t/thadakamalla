﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblBrands", Schema = "dbo")]
    public class Brand : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int BrandID { get; set; }
        [Required(ErrorMessage = "Enter Brand Name")]
        public string BrandName { get; set; }
        public string BrandDescription { get; set; }
    }
}
