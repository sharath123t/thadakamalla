﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblPurchaseOrder", Schema = "dbo")]
    public class PurchaseOrder : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PurchaseOrderID { get; set; }
        public int CartID { get; set; }
        public int StatusID { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        [DefaultValue(0.0)]
        public decimal Amount { get; set; }
        public int CardID { get; set; }

        public bool IsBuyIn { get; set; }

    }
}
