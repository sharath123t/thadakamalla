﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblCustomer", Schema = "dbo")]
    public class Customer : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CustomerID { get; set; }
        public string UserName { get; set; }
        [Required(ErrorMessage = "Enter Name")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "Enter Shipping Address")]
        public string ShippingAddress { get; set; }
        [Required(ErrorMessage = "Enter Billing Address")]
        public string BillingAddress { get; set; }
        public string Gender { get; set; }
        public DateTime? DOB{ get; set; }
    }
}
