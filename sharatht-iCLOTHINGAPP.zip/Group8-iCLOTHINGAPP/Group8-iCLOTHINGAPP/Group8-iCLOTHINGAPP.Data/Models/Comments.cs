﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblComments", Schema = "dbo")]
    public class Comments : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CID { get; set; }
        [Required(ErrorMessage = "Enter Comment/Feedback")]
        public string QueryDesc { get; set; }
        public string UserName { get; set; }
    }
}
