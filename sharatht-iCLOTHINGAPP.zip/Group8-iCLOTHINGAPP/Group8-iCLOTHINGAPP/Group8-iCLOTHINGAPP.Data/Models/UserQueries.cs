﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblQueries", Schema = "dbo")]
    public class UserQueries : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int QID { get; set; }
        [Required(ErrorMessage = "Enter Query")]
        public string QueryDesc { get; set; }
        public string UserName { get; set; }
    }
}
