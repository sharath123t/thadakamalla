﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblCategories", Schema = "dbo")]
    public class Category : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CategoryID { get; set; }
        [Required(ErrorMessage ="Enter Category Name")]
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
    }
}
