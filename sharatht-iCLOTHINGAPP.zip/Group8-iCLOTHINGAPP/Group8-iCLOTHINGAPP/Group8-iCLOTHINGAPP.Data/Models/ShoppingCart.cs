﻿using Group8_iCLOTHINGAPP.Data.Repos;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group8_iCLOTHINGAPP.Data.Models
{
    [Table("tblShoppingCart", Schema = "dbo")]
    public class ShoppingCart : BaseEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CartID { get; set; }
        public string UserName { get; set; }
        public string ShippingAddress { get; set; }
        public string BillingAddress { get; set; }
        public string LineItems { get; set; }
        public bool IsActive { get; set; }
    }
}
