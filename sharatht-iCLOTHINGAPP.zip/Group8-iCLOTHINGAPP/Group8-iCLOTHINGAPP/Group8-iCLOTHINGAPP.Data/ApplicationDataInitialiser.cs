﻿using Microsoft.AspNetCore.Identity;

namespace Group8_iCLOTHINGAPP.Data
{
    public static class ApplicationDataInitialiser
    {
        public static void SeedData(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            SeedRoles(roleManager);
            SeedUsers(userManager);
        }
        /// <summary>
        /// This method is used to Insert Admin User with Admin Role on App Loading
        /// </summary>
        /// <param name="userManager"></param>
        public static void SeedUsers(UserManager<IdentityUser> userManager)
        {
            if (userManager.FindByNameAsync("Admin").Result == null)
            {
                var user = new IdentityUser
                {
                    UserName = "Admin",
                    Email = "admin@iclothing.com",
                    NormalizedUserName = "ADMIN",
                };

                var password = "Admin@123";

                var result = userManager.CreateAsync(user, password).Result;

                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user, "Admin").Wait();
                }
            }
        }
        /// <summary>
        /// This method id used to seed the roles into database
        /// </summary>
        /// <param name="roleManager"></param>
        public static void SeedRoles(RoleManager<IdentityRole> roleManager)
        {
            if (!roleManager.RoleExistsAsync("Admin").Result)
            {
                var role = new IdentityRole
                {
                    Name = "Admin"
                };
                roleManager.CreateAsync(role).Wait();
            }
            if (!roleManager.RoleExistsAsync("User").Result)
            {
                var role = new IdentityRole
                {
                    Name = "User"
                };
                roleManager.CreateAsync(role).Wait();
            }
        }
    }
}
