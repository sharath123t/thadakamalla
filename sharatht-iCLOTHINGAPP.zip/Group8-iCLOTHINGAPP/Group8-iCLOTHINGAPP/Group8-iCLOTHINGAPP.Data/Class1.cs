﻿using System;

namespace Group8_iCLOTHINGAPP.Data
{
    public class Class1
    {
    }
}
