﻿using System.Collections.Generic;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public List<string> Errors { get; set; }
    }
}
