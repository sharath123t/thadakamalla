﻿using Group8_iCLOTHINGAPP.Data.Models;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class CardViewModel :CreditCard
    {
        public decimal Amount { get; set; }
        public bool IsBuyNow{ get; set; }
        public int ProdId { get; set; }
    }
}
