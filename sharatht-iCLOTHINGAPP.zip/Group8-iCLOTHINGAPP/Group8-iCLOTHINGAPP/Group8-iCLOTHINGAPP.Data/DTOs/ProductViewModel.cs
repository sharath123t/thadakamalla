﻿using Group8_iCLOTHINGAPP.Data.Models;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class ProductViewModel : Product
    {
        public IFormFile File { get; set; }
        public string CategoryName { get; set; }
        public string DepartmentName { get; set; }
        public string BrandName { get; set; }
        public bool IsLastItem { get; set; }
    }

    public class SearchResultsModel
    {
        public IEnumerable<Category> Categories { get; set; }
        public IEnumerable<Brand> Brands { get; set; }
        public IEnumerable<Department> Departments { get; set; }
        public IEnumerable<ProductViewModel> Products { get; set; }
        public int Total { get; set; }

    }
}
