﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class BillingDetails : CardViewModel
    {
        public int POID { get; set; }
        public string CustomerName{ get; set; }
        public string UserName{ get; set; }
        public DateTime? OrderDate{ get; set; }
       
    }
    public class BillingViewModel 
    {
        public bool IsAdmin{ get; set; }
        public IEnumerable<BillingDetails> Billings{ get; set; }

    }
}
