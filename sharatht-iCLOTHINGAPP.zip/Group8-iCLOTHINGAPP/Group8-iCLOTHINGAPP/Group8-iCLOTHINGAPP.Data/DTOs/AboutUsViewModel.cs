﻿using Group8_iCLOTHINGAPP.Data.Models;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class AboutUsViewModel 
    {
        public ResponseModel Response { get; set; }
        public AboutUs AboutUs { get; set; }
    }
}
