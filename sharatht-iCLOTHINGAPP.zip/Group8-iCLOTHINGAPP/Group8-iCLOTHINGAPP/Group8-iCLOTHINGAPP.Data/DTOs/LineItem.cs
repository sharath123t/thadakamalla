﻿using Group8_iCLOTHINGAPP.Data.Models;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class LineItems : Product
    {
        public decimal Price { get; set; }
        public int OrderQuantity { get; set; }
        public string BrandName { get; set; }
        public string CategoryName { get; set; }
        public string Department { get; set; }
        public bool IsLast{ get; set; }
    }
}
