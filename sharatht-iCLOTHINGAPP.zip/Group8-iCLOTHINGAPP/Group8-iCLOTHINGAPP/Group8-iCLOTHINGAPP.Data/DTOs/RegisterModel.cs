﻿using System.ComponentModel.DataAnnotations;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class RegisterModel : ResponseModel
    {
        [Required(ErrorMessage = "Enter UserName")]
        public string UserName { get; set; }
        [EmailAddress]
        [Required(ErrorMessage = "Enter Email Address")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Password and confirmation password not match.")]
        public string ConfirmPassword { get; set; }
    }
}
