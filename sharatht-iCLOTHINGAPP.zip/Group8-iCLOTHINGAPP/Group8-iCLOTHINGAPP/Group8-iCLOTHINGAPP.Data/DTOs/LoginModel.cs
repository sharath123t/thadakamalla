﻿using System.ComponentModel.DataAnnotations;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class LoginModel : ResponseModel
    {
        [Required(ErrorMessage = "Enter UserName")]
        public string UserName { get; set; }
    
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string Role { get; set; }
    }
}
