﻿using Group8_iCLOTHINGAPP.Data.Models;
using System.Collections.Generic;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class AdminDBViewModel
    {
        public List<UserQueries> Queries { get; set; }
        public List<Comments> Comments{ get; set; }
    }
}
