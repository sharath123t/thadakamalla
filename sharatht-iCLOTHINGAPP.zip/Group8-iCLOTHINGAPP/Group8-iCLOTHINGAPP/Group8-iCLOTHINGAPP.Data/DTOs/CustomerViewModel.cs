﻿using Group8_iCLOTHINGAPP.Data.Models;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class CustomerViewModel : Customer
    {
        public ResponseModel Response { get; set; }
        public string EmailAddress { get; set; }
    }
}
