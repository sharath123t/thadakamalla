﻿using System.Collections.Generic;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class CartResultModel:ResponseModel
    {
        public int TotalItems { get; set; }
        public int CartID { get; set; }
        public decimal CartTotal { get; set; }
        public List<LineItems> Products { get; set; }
        public bool IsBuyNow { get; set; }
    }
}
