﻿using Group8_iCLOTHINGAPP.Data.Models;
using System;
using System.Collections.Generic;

namespace Group8_iCLOTHINGAPP.Data.DTOs
{
    public class PurchaseOrderViewModel
    {
        public List<PurchaseOrders> Orders { get; set; }
        public bool IsAdmin { get; set; }
    }

    public class PurchaseOrders
    {
        public int PoID { get; set; }
        public int CartID { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public string UserName { get; set; }
        public CartResultModel Cart { get; set; }
        public CreditCard CardDetails { get; set; }
        public Customer Customer { get; set; }
        public DateTime? OrderDate { get; set; }
        public bool IsBuyIn { get; set; }
    }
}
