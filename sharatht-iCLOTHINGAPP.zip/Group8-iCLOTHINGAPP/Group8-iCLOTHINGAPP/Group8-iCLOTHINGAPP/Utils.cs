﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP
{
    public static class Utils
    {
        //This static method is used to upload the file into file system
        public static string UploadFile(IFormFile file)
        {
            try
            {
                string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/products");
                //creates new folder if not exist
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
                FileInfo fileInfo = new FileInfo(file.FileName);
                string fileName = Guid.NewGuid() + fileInfo.Extension;
                string fileNameWithPath = Path.Combine(path, fileName);
                using (var stream = new FileStream(fileNameWithPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
                return string.Concat("/products/", fileName);
            }
            catch (Exception ex)
            {
                return string.Empty;
            }

        }
        /// <summary>
        /// This method is used to delete the file from file system
        /// </summary>
        /// <param name="filePath"></param>
        public static void DeleteFile(string filePath)
        {
            try
            {
                string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/products");
                // Check if file exists with its full path    
                if (File.Exists(Path.Combine(path, filePath.Split("/")[2])))
                {
                    // If file found, delete it    
                    File.Delete(Path.Combine(path, filePath.Split("/")[2]));
                    Console.WriteLine("File deleted.");
                }
                else Console.WriteLine("File not found");
            }
            catch (IOException ioExp)
            {
                Console.WriteLine(ioExp.Message);
            }

        }
    }
}
