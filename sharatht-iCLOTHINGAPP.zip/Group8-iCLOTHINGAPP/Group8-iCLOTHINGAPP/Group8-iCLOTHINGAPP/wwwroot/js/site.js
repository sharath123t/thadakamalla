﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
var recordTobeDeleted;
var deleteUrl = '';
function DeleteRecord(id, url) {
    recordTobeDeleted = id;
    deleteUrl = url;
}
function confirmDelete() {
    $.ajax({
        url: deleteUrl + recordTobeDeleted,
        type: "Get",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            if (result == true) {
                location.reload();
            }
            else {

            }
        },
    });
}
$('#cancelDelete').click(function () {
    recordTobeDeleted = 0;
    deleteUrl = '';
})

function addToCart(prodId, quantity) {
    $.ajax({
        type: "GET",
        url: "/ShoppingCart/AddToCart",
        data: { prodId: prodId, quantity: quantity },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            console.log(r);
            if (!r.isSuccess) {
                alert(r.message)
            }
            else {
                $('#cartItemCount').text(r.totalItems)
            }
        }
    });
}

function getCart() {
    $.ajax({
        type: "GET",
        url: "/ShoppingCart/GetCartItems",
        data: {},
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            console.log(r);
            if (r != null) {
                $('#cartItemCount').text(r)
            }
        }
    });
}

function removeItem(prodId) {
    $('#' + prodId).remove();
    $.ajax({
        type: "GET",
        url: "/ShoppingCart/RemovefromCart",
        data: { prodId: prodId },
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            if (r == null) {
                $('#divCart').hide();

                $('#cartBody').append('<div class="alert alert-warning" id="divNoProducts"><h3>Your cart is empty</h3><h5 class="mb-3"><a asp-controller="Products" asp-action="Index" class= "text-body">' +
                    '<i class="fas fa-long-arrow-alt-left me-2"></i>Continue shopping</a ></h5 ></div>');
            }
            else {
                if (!r.isSuccess) {
                    alert(r.message)
                }
                else if (r.cartTotal == 0) {
                    $('#divCart').hide();

                    $('#cartBody').append('<div class="alert alert-warning" id="divNoProducts"><h3>Your cart is empty</h3><h5 class="mb-3"><a asp-controller="Products" asp-action="Index" class= "text-body">' +
                        '<i class="fas fa-long-arrow-alt-left me-2"></i>Continue shopping</a ></h5 ></div>');
                    $('#cartItemCount, #cartItmes').text(r.totalItems)
                    $('.cart-total').text(r.cartTotal.toFixed(2))
                    $('#Amount').val(r.cartTotal)
                }
                else {
                    $('#cartItemCount, #cartItmes').text(r.totalItems)
                    $('.cart-total').text(r.cartTotal.toFixed(2))
                    $('#Amount').val(r.cartTotal)
                }
            }

        }
    });
}
