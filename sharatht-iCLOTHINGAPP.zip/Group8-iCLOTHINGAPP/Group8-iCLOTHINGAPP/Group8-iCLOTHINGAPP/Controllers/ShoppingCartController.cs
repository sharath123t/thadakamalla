﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Group8_iCLOTHINGAPP.Controllers
{
    [Authorize(Roles = "User")]
    public class ShoppingCartController : Controller
    {
        private readonly ICartService _cartService;

        public ShoppingCartController(ICartService cartService)
        {
            this._cartService = cartService;

        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Success()
        {
            return View();
        }
        public IActionResult Cart()
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var res = _cartService.GetCart(userName);
            return View(res);
        }
        public JsonResult AddToCart(int prodId, int quantity)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var res = _cartService.AddToCart(prodId, quantity, userName);
            return Json(res);
        }
        public JsonResult RemovefromCart(int prodId)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var res = _cartService.RemoveProductFromCart(userName, prodId);
            return Json(res);
        }
        public JsonResult GetCartItems()
        {
            ClaimsPrincipal currentUser = this.User;
            if (currentUser.Identity.IsAuthenticated)
            {
                var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
                var res = _cartService.GetCartItemsCount(userName);
                return Json(res);
            }
            return Json(0);

        }
        public JsonResult PlaceOrder(decimal? amount, string cvv, string cardHolderName, string cardNumber, string expiryDate, int prodId = 0, bool isBuyNow = false)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var model = new CardViewModel
            {
                Amount = amount ?? 0M,
                CardHolderName = cardHolderName,
                ExpiryDate = expiryDate,
                CVV = cvv,
                CardNumber = cardNumber,
                IsBuyNow = isBuyNow,
                ProdId = prodId
            };
            if (isBuyNow && prodId != 0)
                return Json(_cartService.PlaceOrderForBuyNow(userName, model));
            var res = _cartService.PlaceOrder(userName, model);
            return Json(res);
        }
        public IActionResult BuyNow(int prodId)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var res = _cartService.BuyNow(prodId, userName);
            return View("Cart", res);
        }
    }
}
