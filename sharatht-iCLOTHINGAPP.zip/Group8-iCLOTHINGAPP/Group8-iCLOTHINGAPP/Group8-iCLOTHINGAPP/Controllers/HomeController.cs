﻿using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Models;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ICatalogService _catalogService;
        private readonly IAdminService _adminService;
        private readonly IUserService _userService;

        public HomeController(ILogger<HomeController> logger, ICatalogService catalogService,
            IAdminService adminService, IUserService userService)
        {
            _logger = logger;
            this._catalogService = catalogService;
            this._adminService = adminService;
            this._userService = userService;
        }

        public IActionResult Index()
        {
            var model = _catalogService.GetRandomProducts();
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            var aboutUS = _adminService.GetAboutUs(0);
            return View(aboutUS);
        }

        public async Task<IActionResult> SubmitFeedback(string userName, string queryDesc)
        {
            var mdl = new Comments
            {
                UserName = userName,
                QueryDesc = queryDesc,
                CreatedBy = userName,
                CreatedOn = DateTime.Now
            };
            bool res = await _userService.InsertComments(mdl);
            if (res)
                TempData["msg"] = "Thanks!! Your feedback has been submitted successfully!";
            else
                TempData["msg"] = "Sorry! Something went wrong";
            return RedirectToAction("AboutUs");
        }

        public async Task<IActionResult> SubmitQuery(string userName, string queryDesc)
        {
            var mdl = new UserQueries
            {
                UserName = userName,
                QueryDesc = queryDesc,
                CreatedBy = userName,
                CreatedOn = DateTime.Now
            };
            bool res = await _userService.InsertQueries(mdl);
            if (res)
                TempData["msg"] = "Thanks!! Your query has been submitted successfully!";
            else
                TempData["msg"] = "Sorry! Something went wrong";
            return RedirectToAction("AboutUs");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
