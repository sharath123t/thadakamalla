﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CatalogController : Controller
    {
        private readonly ICatalogService _catalogService;

        public CatalogController(ICatalogService catalogService)
        {
            this._catalogService = catalogService;

        }
        public IActionResult Department()
        {
            return View();
        }
        public IActionResult Catagory()
        {
            ViewBag.Departments = _catalogService.GetAllDepartments();
            return View();
        }

        public IActionResult Brands()
        {

            return View();
        }
        public IActionResult Products()
        {
            ViewBag.Categories = _catalogService.GetAllCategories();
            ViewBag.Brands = _catalogService.GetAllBrands();
            ViewBag.Departments = _catalogService.GetAllDepartments();
            return View();
        }

        #region "Brands"
        [HttpPost]
        public async Task<IActionResult> Brands(Brand brand)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            if (brand.BrandID == 0)
            {
                brand.CreatedBy = userName;
                brand.CreatedOn = DateTime.Now;
            }
            else
            {
                brand.ModifiedBy = userName;
                brand.ModifiedOn = DateTime.Now;
            }
            bool res = await _catalogService.UpSertBrand(brand);
            ModelState.Clear();
            return View();
        }

        public JsonResult GetBrands()
        {
            var brands = _catalogService.GetAllBrands();
            return Json(brands);
        }

        public JsonResult GetBrand(int brandId)
        {
            var res = _catalogService.GetBrand(brandId);
            return Json(res);
        }

        public JsonResult DeleteBrand(int brandId)
        {
            var res = _catalogService.DeleteBrand(brandId);
            return Json(res);
        }

        #endregion

        #region "Departments"
        [HttpPost]
        public async Task<IActionResult> Department(Department dept)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            if (dept.DepartmentID == 0)
            {
                dept.CreatedBy = userName;
                dept.CreatedOn = DateTime.Now;
            }
            else
            {
                dept.ModifiedBy = userName;
                dept.ModifiedOn = DateTime.Now;
            }
            bool res = await _catalogService.UpSertDepartment(dept);
            ModelState.Clear();
            return RedirectToAction();
        }

        public JsonResult GetDepartments()
        {
            var brands = _catalogService.GetAllDepartments();
            return Json(brands);
        }

        public JsonResult GetDepartment(int deptId)
        {
            var res = _catalogService.GetDepartment(deptId);
            return Json(res);
        }

        public JsonResult DeleteDepartment(int deptId)
        {
            var res = _catalogService.DeleteDepartment(deptId);
            return Json(res);
        }

        #endregion

        #region "Categories"
        [HttpPost]
        public async Task<IActionResult> Catagory(Category category)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            if (category.CategoryID == 0)
            {
                category.CreatedBy = userName;
                category.CreatedOn = DateTime.Now;
            }
            else
            {
                category.ModifiedBy = userName;
                category.ModifiedOn = DateTime.Now;
            }


            bool res = await _catalogService.UpSertCategory(category);
            ModelState.Clear();
            return RedirectToAction();
        }

        public JsonResult GetCategories()
        {
            var Categories = _catalogService.GetAllCategories();
            return Json(Categories);
        }

        public JsonResult GetCategory(int categoryId)
        {
            var res = _catalogService.GetCategory(categoryId);
            return Json(res);
        }

        public JsonResult DeleteCategory(int categoryId)
        {
            var res = _catalogService.DeleteCategory(categoryId);
            return Json(res);
        }

        #endregion

        #region "Products"
        [HttpPost]
        public async Task<IActionResult> Products(ProductViewModel productVM)
        {
            var imagePath = string.Empty;
            if (productVM.File != null)
            {
                imagePath = Utils.UploadFile(productVM.File);
            }
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var product = new Product
            {
                ProductID = productVM.ProductID,
                ProductName = productVM.ProductName,
                ProductDescription = productVM.ProductDescription,
                ProductPrice = productVM.ProductPrice,
                ProductQuantity = productVM.ProductQuantity,
                BrandID = productVM.BrandID,
                CategoryID = productVM.CategoryID,
                DepartmentID = productVM.DepartmentID,
                ImagePath = string.IsNullOrEmpty(productVM.ImagePath) ? imagePath : productVM.ImagePath,
                CreatedBy = productVM.ProductID == 0 ? userName : string.Empty,
                CreatedOn = productVM.ProductID == 0 ? DateTime.Now : null,
                ModifiedBy = productVM.ProductID != 0 ? string.Empty : userName,
                ModifiedOn = productVM.ProductID != 0 ? null : DateTime.Now,
            };
            bool res = await _catalogService.UpSertProduct(product);
            ModelState.Clear();

            return RedirectToAction();
        }
        public JsonResult GetProducts()
        {
            var products = _catalogService.GetAllProducts();
            return Json(products);
        }

        public JsonResult GetProduct(int prodId)
        {
            var res = _catalogService.GetProduct(prodId);
            return Json(res);
        }

        public JsonResult DeleteProduct(int prodId, string path)
        {
            if (!string.IsNullOrEmpty(path))
                Utils.DeleteFile(path);
            var res = _catalogService.DeleteProduct(prodId);
            return Json(res);
        }
        #endregion
    }
}
