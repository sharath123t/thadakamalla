﻿using Group8_iCLOTHINGAPP.Data.DTOs;
using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;
        public AccountController(IAccountService accountService)
        {
            this._accountService = accountService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Profile()
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var profile = _accountService.GetProfile(userName);
            return View(profile);
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel obj)
        {
            var res = await _accountService.RegisterUser(obj);
            return View(res);
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel obj)
        {
            var res = await _accountService.LoginUser(obj);
            if (res.IsSuccess)
            {
                if (res.Role.Equals("Admin"))
                    return RedirectToAction("Index", "Admin");
                return RedirectToAction("Index", "Home");
            }
            return View(res);
        }

        public async Task<IActionResult> Logout()
        {
            await _accountService.Logout();
            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult Profile(CustomerViewModel obj)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var customer = new Customer
            {
                CustomerID = obj.CustomerID,
                CustomerName = obj.CustomerName,
                ShippingAddress = obj.ShippingAddress,
                BillingAddress = obj.BillingAddress,
                Gender = obj.Gender,
                DOB = obj.DOB,
                UserName = userName,
                CreatedBy = obj.CustomerID == 0 ? userName : string.Empty,
                CreatedOn = obj.CustomerID == 0 ? DateTime.Now : null,
                ModifiedBy = obj.CustomerID != 0 ? string.Empty : userName,
                ModifiedOn = obj.CustomerID != 0 ? null : DateTime.Now,
            };
            var res = _accountService.UpsertCustomer(customer);
            return RedirectToAction("Profile");
        }
    }
}
