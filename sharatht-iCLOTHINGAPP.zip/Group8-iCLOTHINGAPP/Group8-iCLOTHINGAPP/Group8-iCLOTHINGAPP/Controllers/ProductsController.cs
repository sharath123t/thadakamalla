﻿using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Group8_iCLOTHINGAPP.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ICatalogService _catalogService;

        public ProductsController(ICatalogService catalogService)
        {
            this._catalogService = catalogService;

        }
        public IActionResult Index(string searchTerm = null,string category = null, string department = null,string brands = null)
        {
            var result = _catalogService.Search(searchTerm, category, department, brands);
            return View(result);
        }

        public IActionResult Details(int productId)
        {
            var product = _catalogService.GetRandomProducts(productId)?.FirstOrDefault();
            return View(product);
        }
    }
}
