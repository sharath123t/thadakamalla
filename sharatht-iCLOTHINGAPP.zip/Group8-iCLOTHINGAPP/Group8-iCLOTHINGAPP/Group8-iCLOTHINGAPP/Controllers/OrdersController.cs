﻿using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Group8_iCLOTHINGAPP.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            this._orderService = orderService;

        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Details(int poId)
        {
            var order = _orderService.GetOrder(poId);
            return View(order);
        }


        public IActionResult Orders()
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var role = currentUser?.FindFirst(ClaimTypes.Role).Value;
            var orders = _orderService.GetOrders(userName, role);
            return View(orders);
        }

        public IActionResult UpdateStatus(int poId, int status)
        {
            var success = _orderService.UpdateOrderStatus(poId, status);
            return RedirectToAction("Orders");
        }
    }
}
