﻿using Group8_iCLOTHINGAPP.Data.Models;
using Group8_iCLOTHINGAPP.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Group8_iCLOTHINGAPP.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly IAdminService _adminService;
        private readonly IOrderService _orderService;

        public AdminController(IAdminService adminService, IOrderService orderService)
        {
            this._adminService = adminService;
            this._orderService = orderService;
        }
        public IActionResult Index()
        {
            var model = _adminService.GetAdminDB();
            return View(model);
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult Users()
        {
            var users = _adminService.GetUsers();
            return View(users);
        }

        public IActionResult Billing()
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            var role = currentUser?.FindFirst(ClaimTypes.Role).Value;
            var billings = _orderService.GetBillings(userName, role);
            return View(billings);
        }
        #region "AboutUs"
        [HttpPost]
        public async Task<IActionResult> AboutUs(AboutUs aboutUs)
        {
            ClaimsPrincipal currentUser = this.User;
            var userName = currentUser?.FindFirst(ClaimTypes.Name).Value;
            if (aboutUs.AID == 0)
            {
                aboutUs.CreatedBy = userName;
                aboutUs.CreatedOn = DateTime.Now;
            }
            else
            {
                aboutUs.ModifiedBy = userName;
                aboutUs.ModifiedOn = DateTime.Now;
            }
            bool res = await _adminService.UpSertAboutUs(aboutUs);
            ModelState.Clear();
            return View();
        }

        public JsonResult GetAllAboutUs()
        {
            var AboutUs = _adminService.GetAllAboutUS();
            return Json(AboutUs);
        }

        public JsonResult GetAboutUsById(int aboutUsId)
        {
            var res = _adminService.GetAboutUs(aboutUsId);
            return Json(res);
        }
        #endregion
    }
}
